<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .conta {
            background-color: blue;
            width: 100%;
            height: auto;
            color: white;
        }

    </style>
</head>


<body>
    <div class="conta">
    <?php
    $nome = "Jean";
    $sobrenome = "Lucas";
    $idade = "22";
    $altura = "1.78";
    $ativo = true;
    $mensagem = $nome . "<br>" . $sobrenome . "<br>" . $idade . "<br>" . $altura . "<br>" . $ativo;
    echo $mensagem;


    ?>



</body>

</html>