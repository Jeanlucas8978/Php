<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a = 5;
        $b = 10;

        echo "Antes: a =" . $a . "<br>";
        echo "Antes: b =" . $b . "<br>";

        $var_temp = $a;
        $a = $b;
        $b = $var_temp;

        echo "Depois: a =" . $a . "<br>";
        echo "Depois: b =" . $b . "<br>";



    ?>
</body>
</html>