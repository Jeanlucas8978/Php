<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <style>
        body {

            font-size: 40px;
            background: rgb(2, 0, 36);
            background: linear-gradient(90deg, rgba(254, 254, 254, 1) 0%, rgb(51, 51, 71) 100%, rgba(0, 0, 0, 1) 100%, rgba(255, 255, 255, 1) 100%);
            color: antiquewhite;
            text-align: center;
            padding-top: 10%;

        }

        .info {

            position: absolute;
            top: 10PX;
            align-content: center;
            border-radius: 10px;
            width: 100%;
            height: 200px;
            background-color: rgb(75, 104, 99);
            animation: blink 2s linear infinite;

        }
    </style>
    </head>

    <body>
        <div class="info">

            <?php
            $preço = 25;
            $quantidade = 2;
            $total = $preço * $quantidade;
            echo $preço . "x" . " " . $quantidade . "<br>";
            echo "Total da compra:" . $total;
            ?>
        </div>








    </body>

</html>