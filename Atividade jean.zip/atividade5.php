<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        $nome = "Jean";
        $salario = "1.620";
        $idade = "22";
        $ativo = true;
        echo "O conteúdo da variavel nome é: <br>"; 
        var_dump($nome);
        echo "<br>";
        echo "Meu salario é";
        var_dump($salario);
        echo "<br>";
        echo "Minha idade é";
        var_dump($idade);
    
        
        

    ?>
</body>

</html>